# Proyecto-IAW
Proyecto IAW de página web.

## Introducción al proyecto

El proyecto consiste en la realización de una página web personalizada usando una plantilla html/css donde incluiremos inicio de sesión de usuarios usando php y mysql, con la ayuda de las plantillas de https://configuroweb.com y un carrito de compra integrado con función de insertar y modificar productos dependiendo del rol de tu usuario.
